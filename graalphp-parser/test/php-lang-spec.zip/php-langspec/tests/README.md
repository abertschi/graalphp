# The PHP Specification Test Suite

If you pass this suite, you aren't necessarily spec compliant, but it is a helpful bellwether.

## Usage

To run using the PHP test runner, do something like:

    TEST_PHP_EXECUTABLE=~/php-src/sapi/cli/php ~/php-src/run-tests.php /tmp/phpt
