# Bibliography

The following documents are useful references for implementers and users
of this specification:

IEC 60559:1989, *Binary floating-point arithmetic for microprocessor
systems* (previously designated IEC 559:1989). (This standard is widely
known by its U.S. national designation, ANSI/IEEE Standard 754-1985,
IEEE Standard for Binary Floating-Point Arithmetic).

The Unicode Consortium. *The Unicode Standard, Version 5.0*,
[www.Unicode.org](http://www.Unicode.org)).
